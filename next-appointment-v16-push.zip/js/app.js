/* =========================================
   Next Appointment — App logic (main)
   ========================================= */

const App = {
  currentEditId: null,
  tickInterval: null,
  activeCategory: 'all',
  searchQuery: '',

  init() {
    // Iconos: reemplaza todos los botones con data-icon por su SVG inline.
    // Envuelto en try/catch: si esto fallara (ej. caché desincronizada tras
    // una actualización), no debe impedir que el resto de la app arranque.
    try {
      document.querySelectorAll('[data-icon]').forEach((el) => {
        if (typeof setIcon === 'function') setIcon(el, el.dataset.icon);
      });
    } catch (e) {
      console.warn('No se pudieron inicializar los iconos', e);
    }

    // Theme
    const savedTheme = Storage.getTheme();
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const theme = savedTheme || (prefersDark ? 'dark' : 'light');
    UI.applyTheme(theme);

    document.getElementById('btn-theme').addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      UI.applyTheme(next);
      Storage.setTheme(next);
    });

    // Navigation
    document.getElementById('btn-list').addEventListener('click', () => {
      this.renderAll();
      UI.showView('view-list', 'right');
    });

    document.querySelectorAll('.back-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.renderAll();
        UI.showView(btn.dataset.target, 'left');
      });
    });

    document.getElementById('btn-create').addEventListener('click', () => this.openCreateForm());
    document.getElementById('btn-create-from-list').addEventListener('click', () => this.openCreateForm());
    document.getElementById('btn-empty-create').addEventListener('click', () => this.openCreateForm());

    document.getElementById('btn-delete-event').addEventListener('click', () => this.deleteCurrentEvent());

    // Sort bar
    document.querySelectorAll('.sort-chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        Storage.setSortMode(chip.dataset.sort);
        UI.renderSortBar(chip.dataset.sort);
        this.refreshList();
      });
    });

    // Búsqueda en la lista (filtra en vivo)
    const searchInput = document.getElementById('search-input');
    searchInput.addEventListener('input', () => {
      this.searchQuery = searchInput.value;
      document.getElementById('btn-clear-search').classList.toggle('hidden', !this.searchQuery);
      this.refreshList();
    });
    document.getElementById('btn-clear-search').addEventListener('click', () => {
      this.searchQuery = '';
      searchInput.value = '';
      document.getElementById('btn-clear-search').classList.add('hidden');
      this.refreshList();
      searchInput.focus();
    });

    // Form
    document.getElementById('event-form').addEventListener('submit', (e) => this.handleSubmit(e));
    ['event-name', 'event-date', 'event-time'].forEach((id) => {
      document.getElementById(id).addEventListener('input', () => this.updatePreview());
    });

    // Modo rápido: mostrar/ocultar campos avanzados
    document.getElementById('btn-toggle-advanced').addEventListener('click', () => {
      const isExpanded = document.getElementById('btn-toggle-advanced').getAttribute('aria-expanded') === 'true';
      this.toggleAdvancedFields(!isExpanded);
    });

    // Repeat toggle (cantidad + unidad, estilo alarma)
    document.getElementById('event-repeat-toggle').addEventListener('change', (e) => {
      this.toggleRepeatRow(e.target.checked);
      this.updatePreview();
    });
    document.getElementById('event-recurrence-interval').addEventListener('input', () => this.updatePreview());
    document.getElementById('event-recurrence-unit').addEventListener('change', () => this.updatePreview());
    document.getElementById('event-recurrence-end-date').addEventListener('change', () => this.updatePreview());
    document.getElementById('event-recurrence-max-count').addEventListener('input', () => this.updatePreview());

    // Share modal
    document.getElementById('btn-copy-link').addEventListener('click', () => this.copyShareLink());
    document.getElementById('btn-share-close').addEventListener('click', () => UI.hideModal('modal-share'));
    document.getElementById('btn-share-native').addEventListener('click', () => this.nativeShareLink());

    // Import modal
    document.getElementById('btn-import-cancel').addEventListener('click', () => this.dismissImport());
    document.getElementById('btn-import-accept').addEventListener('click', () => this.acceptImport());

    // Paste-to-import modal
    document.getElementById('btn-open-import').addEventListener('click', () => this.openPasteImportModal());
    document.getElementById('btn-paste-import-cancel').addEventListener('click', () => UI.hideModal('modal-paste-import'));
    document.getElementById('btn-paste-import-confirm').addEventListener('click', () => this.confirmPasteImport());
    document.getElementById('modal-paste-import').addEventListener('click', (e) => {
      if (e.target.id === 'modal-paste-import') UI.hideModal('modal-paste-import');
    });

    // File picker inside paste-import modal
    document.getElementById('btn-paste-import-file').addEventListener('click', () => {
      document.getElementById('import-file-input').click();
    });
    document.getElementById('import-file-input').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) this.importFromFile(file);
      e.target.value = '';
    });

    // Export modal
    document.getElementById('btn-open-export').addEventListener('click', () => this.openExportModal());
    document.getElementById('btn-export-download').addEventListener('click', () => this.exportAsJson());
    document.getElementById('btn-export-clipboard').addEventListener('click', () => this.exportToClipboard());
    document.getElementById('btn-export-close').addEventListener('click', () => UI.hideModal('modal-export'));
    document.getElementById('modal-export').addEventListener('click', (e) => {
      if (e.target.id === 'modal-export') UI.hideModal('modal-export');
    });

    // Bulk JSON import confirmation modal
    document.getElementById('btn-import-json-cancel').addEventListener('click', () => UI.hideModal('modal-import-json'));
    document.getElementById('btn-import-json-accept').addEventListener('click', () => this.acceptBulkJsonImport());
    document.getElementById('modal-import-json').addEventListener('click', (e) => {
      if (e.target.id === 'modal-import-json') UI.hideModal('modal-import-json');
    });

    // Notificaciones push (feature 005)
    document.getElementById('btn-open-push-settings').addEventListener('click', () => this.openPushSettings());
    document.getElementById('btn-push-close').addEventListener('click', () => UI.hideModal('modal-push-settings'));
    document.getElementById('btn-push-toggle').addEventListener('click', () => this.togglePush());
    document.getElementById('modal-push-settings').addEventListener('click', (e) => {
      if (e.target.id === 'modal-push-settings') UI.hideModal('modal-push-settings');
    });

    // Archivados
    document.getElementById('btn-open-archived').addEventListener('click', () => {
      this.renderArchivedView();
      UI.showView('view-archived', 'right');
    });

    // Close modals when clicking the overlay (outside the card)
    document.getElementById('modal-import').addEventListener('click', (e) => {
      if (e.target.id === 'modal-import') this.dismissImport();
    });
    document.getElementById('modal-share').addEventListener('click', (e) => {
      if (e.target.id === 'modal-share') UI.hideModal('modal-share');
    });

    // Banner de recurrentes perdidos
    document.getElementById('btn-missed-recurring-close').addEventListener('click', () => {
      UI.hideModal('modal-missed-recurring');
    });

    // Onboarding: si nunca se ha visto y no hay eventos, crear uno de ejemplo
    this.ensureOnboardingExample();

    // Archivado automático: archiva eventos pasados hace +24h, purga archivados +30 días
    this.runArchiveMaintenance();

    // Banner de eventos recurrentes cumplidos mientras la app estaba cerrada
    this.checkMissedRecurringEvents();

    // Guardar timestamp de esta apertura (para la próxima vez)
    Storage.setLastSeen();

    // Cuando la app vuelve a primer plano (desde segundo plano),
    // repetir la comprobación de eventos recurrentes perdidos
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        this.checkMissedRecurringEvents();
        Storage.setLastSeen();
        this.runArchiveMaintenance();
        this.renderAll();
      }
    });

    // Initial render
    this.renderAll();
    this.startTicking();

    // Service worker
    this.registerServiceWorker();

    // Push: sincroniza el estado real de la suscripción y reprograma los
    // avisos pendientes en el Worker (TASK-005-014). Asíncrono y aislado:
    // si algo falla, la app sigue funcionando igual que siempre.
    Push.init(Storage.getActive()).catch((e) => console.warn('[push] init', e));

    // Check if URL has a shared event to import
    this.checkForSharedEvent();
  },

  /** Renderiza carrusel + lista con los datos actuales */
  renderAll() {
    const allEvents = Storage.getAll();
    const activeEvents = Storage.getActive();
    const sortMode = Storage.getSortMode();
    UI.renderCarousel(activeEvents);
    UI.renderCategoryFilterBar(activeEvents, this.activeCategory);
    UI.renderList(activeEvents, sortMode, this.activeCategory, this.searchQuery);
    UI.renderSortBar(sortMode);
    this.checkCelebrations(allEvents);
    this.checkNotifications(allEvents);
  },

  /**
   * Vuelve a renderizar solo la vista de lista, aplicando el filtro de
   * categoría y la búsqueda activos. Usado cuando cambia la búsqueda o el orden.
   */
  refreshList() {
    const events = Storage.getActive();
    UI.renderList(events, Storage.getSortMode(), this.activeCategory, this.searchQuery);
  },

  /**
   * Cambia la categoría activa del filtro en la vista lista y vuelve a renderizar.
   * @param {string} categoryId - 'all' o id de categoría
   */
  setActiveCategory(categoryId) {
    this.activeCategory = categoryId;
    const events = Storage.getActive();
    UI.renderCategoryFilterBar(events, this.activeCategory);
    this.refreshList();
  },

  /**
   * Actualiza solo los números del countdown cada segundo, sin re-renderizar
   * todo el DOM. Optimizado para no degradarse con muchos eventos:
   * - Usa un Map para lookup O(1) en vez de Array.find() por cada card.
   * - Solo toca el DOM de la vista que está realmente visible en pantalla.
   * - En el carrusel, solo actualiza la card visible (scroll-snap solo
   *   muestra una a la vez) en vez de las 50 que pudiera haber en el DOM.
   * checkCelebrations/checkNotifications sí recorren todos los eventos
   * siempre, porque deben dispararse aunque esa categoría no esté visible.
   */
  startTicking() {
    if (this.tickInterval) clearInterval(this.tickInterval);

    this.tickInterval = setInterval(() => {
      const allEvents = Storage.getAll();
      const activeEvents = allEvents.filter((e) => !e.archivedAt);
      const eventsById = new Map(activeEvents.map((e) => [e.id, e]));

      const activeView = document.querySelector('.view.view-active');
      const activeViewId = activeView ? activeView.id : null;

      if (activeViewId === 'view-main') {
        this.updateVisibleCarouselCard(eventsById);
      } else if (activeViewId === 'view-list') {
        this.updateListCountdowns(activeEvents);
      } else if (activeViewId === 'view-form') {
        this.updatePreview();
      }

      this.checkCelebrations(allEvents);
      this.checkNotifications(allEvents);
    }, 1000);
  },

  /**
   * Actualiza el countdown solo de la card del carrusel actualmente
   * visible en pantalla (scroll-snap solo muestra una a la vez), en vez
   * de recorrer todas las cards del DOM aunque no se vean.
   * @param {Map<string, Object>} eventsById
   */
  updateVisibleCarouselCard(eventsById) {
    const carousel = document.getElementById('event-carousel');
    if (!carousel || !carousel.children.length) return;

    const index = Math.round(carousel.scrollLeft / carousel.clientWidth);
    const visibleCard = carousel.children[index];
    if (!visibleCard) return;

    const event = eventsById.get(visibleCard.dataset.id);
    if (event) UI.updateCardCountdown(visibleCard, event);
  },

  /**
   * Actualiza los countdowns (texto corto) de la vista de lista, respetando
   * el filtro de categoría y búsqueda activos.
   * @param {Array<Object>} events
   */
  updateListCountdowns(events) {
    const filteredEvents = UI.filterEvents(events, this.activeCategory, this.searchQuery);
    const listItems = document.querySelectorAll('#event-list .event-list-item');
    if (listItems.length !== filteredEvents.length) return;

    const sorted = UI.sortEvents(filteredEvents, Storage.getSortMode());
    listItems.forEach((li, i) => {
      const countEl = li.querySelector('.event-list-countdown');
      if (countEl && sorted[i]) countEl.textContent = Countdown.shortLabel(sorted[i]);
    });
  },

  /** Comprueba si algún evento acaba de llegar a cero y muestra celebración */
  checkCelebrations(events) {
    events.forEach((event) => {
      if (Countdown.getRecurrence(event).unit !== 'none') return;
      const diff = Countdown.diffMs(event);
      // Si el evento "acaba de" llegar (margen de 2s) y no se ha celebrado ya
      if (diff <= 0 && diff > -2000 && !event._celebrated) {
        event._celebrated = true;
        Storage.upsert(event);

        // No interrumpir si el usuario está editando un formulario o con un modal abierto
        const formOpen = document.getElementById('view-form').classList.contains('view-active');
        const modalOpen = !document.getElementById('modal-import').classList.contains('hidden')
          || !document.getElementById('modal-share').classList.contains('hidden');

        if (!formOpen && !modalOpen) {
          this.showCelebration(event);
        }
      }
    });
  },

  showCelebration(event) {
    document.getElementById('celebration-emoji').textContent = event.emoji || '🎉';
    document.getElementById('celebration-name').textContent = `"${event.name}" — ¡hoy es el día!`;
    UI.showView('view-celebration', 'right');
    UI.launchConfetti();
  },

  /**
   * Comprueba si algún evento debe disparar una notificación de aviso previo.
   * Solo funciona mientras la app está abierta (sin push remoto).
   * @param {Array<Object>} events
   */
  checkNotifications(events) {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    // Si este dispositivo tiene push activo, el aviso lo entrega el sistema
    // operativo desde el Worker: no hay que dispararlo también aquí
    // (TASK-005-013). Sin push, el comportamiento es el de siempre (FR-010).
    if (typeof Push !== 'undefined' && Push.isEnabled()) return;

    events.forEach((event) => {
      if (!event.notifyBefore) return;

      const diffSeconds = Countdown.diffMs(event) / 1000;
      const notifyAt = Number(event.notifyBefore);

      // Ventana de 2 segundos para no perder el disparo entre ticks
      if (diffSeconds <= notifyAt && diffSeconds > notifyAt - 2) {
        const key = `${event.id}_${this.getTargetTimeKey(event)}`;
        if (event._notifiedKey === key) return;

        event._notifiedKey = key;
        Storage.upsert(event);
        this.fireNotification(event);
      }
    });
  },

  /** Devuelve una clave única para la fecha objetivo actual (sirve para recurrentes) */
  getTargetTimeKey(event) {
    return Countdown.getTargetDate(event).getTime();
  },

  /** Muestra una notificación del sistema para un evento */
  fireNotification(event) {
    const label = Countdown.shortLabel(event);
    const title = `${event.emoji || '⏳'} ${event.name}`;
    const body = `Queda ${label} para este evento.`;

    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.ready.then((reg) => {
        reg.showNotification(title, { body, icon: 'icons/icon-192.png' });
      });
    } else {
      try {
        new Notification(title, { body, icon: 'icons/icon-192.png' });
      } catch (e) {
        console.warn('No se pudo mostrar la notificación', e);
      }
    }
  },

  /** Pide permiso de notificaciones al usuario (debe llamarse tras una interacción) */
  requestNotificationPermission() {
    if (!('Notification' in window)) {
      alert('Tu navegador no soporta notificaciones.');
      return Promise.resolve('unsupported');
    }
    if (Notification.permission === 'granted') return Promise.resolve('granted');
    return Notification.requestPermission();
  },

  /**
   * Si la persona nunca ha visto el onboarding y no tiene ningún evento
   * guardado, crea un evento de ejemplo para que entienda de un vistazo
   * qué hace la app. Solo ocurre una vez en la vida de este dispositivo.
   */
  ensureOnboardingExample() {
    if (Storage.hasSeenOnboarding()) return;
    if (Storage.getAll().length > 0) return;

    const exampleDate = new Date();
    exampleDate.setDate(exampleDate.getDate() + 3);
    exampleDate.setHours(exampleDate.getHours() + 14);

    const example = {
      id: generateId(),
      name: 'Así se ve un evento',
      date: exampleDate.toISOString().slice(0, 10),
      time: '09:00',
      emoji: '🎉',
      color: COLOR_OPTIONS[0],
      category: DEFAULT_CATEGORY_ID,
      recurrenceUnit: 'none',
      recurrenceInterval: 1,
      notifyBefore: null,
      isOnboardingExample: true,
      _celebrated: false,
      _notifiedKey: null,
    };

    Storage.upsert(example);
    Storage.markOnboardingSeen();
  },

  /**
   * Sustituye el evento de ejemplo por el formulario de creación real:
   * borra el ejemplo y abre "Nuevo evento". Se usa desde el botón
   * "Crear mi propio evento" que aparece junto al ejemplo.
   */
  replaceOnboardingWithOwnEvent() {
    const example = Storage.getAll().find((e) => e.isOnboardingExample);
    if (example) Storage.remove(example.id);
    this.openCreateForm();
  },

  /**
   * Mantenimiento de archivado automático, se ejecuta al abrir la app:
   * - Archiva eventos NO recurrentes cuya fecha/hora pasó hace 24h o más.
   * - Elimina definitivamente eventos archivados hace 30 días o más.
   * - Archiva al instante las series recurrentes que agotaron su límite
   *   (fecha de fin o número máximo de repeticiones).
   * Las series recurrentes sin límite nunca se archivan: su countdown
   * siempre apunta al futuro.
   */
  runArchiveMaintenance() {
    const ARCHIVE_AFTER_MS = 24 * 60 * 60 * 1000; // 24 horas
    const DELETE_AFTER_MS = 30 * 24 * 60 * 60 * 1000; // 30 días
    const now = Date.now();

    const events = Storage.getAll();
    let changed = false;

    events.forEach((event) => {
      if (event.archivedAt) {
        // Ya archivado: ¿toca eliminarlo definitivamente?
        if (now - event.archivedAt >= DELETE_AFTER_MS) {
          Storage.remove(event.id);
          changed = true;
        }
        return;
      }

      // No archivado: ¿toca archivarlo?
      if (event.isOnboardingExample) return; // el ejemplo no se archiva solo

      // Serie recurrente: solo se archiva si llegó a su límite (feature 002),
      // y en ese caso al instante, sin esperar las 24h de los no recurrentes.
      // Nota: checkCelebrations ignora cualquier evento recurrente, así que
      // archivar aquí nunca dispara una celebración fuera de lugar.
      if (Countdown.getRecurrence(event).unit !== 'none') {
        if (Countdown.isRecurrenceFinished(event)) {
          Storage.archive(event.id);
          changed = true;
        }
        return;
      }

      if (!Countdown.hasElapsed(event)) return;

      const elapsedMs = now - Countdown.getTargetDate(event).getTime();
      if (elapsedMs >= ARCHIVE_AFTER_MS) {
        Storage.archive(event.id);
        changed = true;
      }
    });

    return changed;
  },

  /**
   * Comprueba si algún evento recurrente se cumplió mientras la app estaba
   * cerrada (comparando con el timestamp de la última apertura guardado).
   * Si encuentra alguno, muestra el banner-resumen enumerándolos con nombre
   * y fecha. Solo se muestra si hay al menos uno y hay un lastSeen previo.
   */
  checkMissedRecurringEvents() {
    const lastSeen = Storage.getLastSeen();
    if (!lastSeen) return; // primera apertura, no hay "mientras estaba cerrada"

    const now = Date.now();
    if (now - lastSeen < 60 * 1000) return; // menos de 1 minuto: no mostrar (recargas normales)

    const events = Storage.getActive();
    const missed = [];

    events.forEach((event) => {
      const recurrence = Countdown.getRecurrence(event);
      if (recurrence.unit === 'none') return;

      // Ancla real: la primera ocurrencia tal como la introdujo el usuario,
      // sin el auto-avance de Countdown.getTargetDate.
      const anchor = new Date(`${event.date}T${event.time || '00:00'}:00`);
      
      // Si la primera ocurrencia todavía no ha llegado, no puede existir
      // ninguna ocurrencia "perdida" todavía.
      if (anchor.getTime() > now) return;
       
      // Partimos de la fecha original del evento y avanzamos hasta encontrar
      // la primera ocurrencia que cae dentro de la ventana (lastSeen, now].
      // Límite de retroceso: empezamos desde la ocurrencia anterior a now
      // para evitar iterar desde el año de creación del evento.
      let start = this.subtractRecurrence(
        Countdown.getTargetDate(event),
        recurrence.unit,
        recurrence.interval
      );

      // Retroceder lo suficiente para cubrir toda la ventana
    let guard = 0;
    while (start.getTime() > lastSeen && start.getTime() > anchor.getTime() && guard < 10000) {
      start = this.subtractRecurrence(start, recurrence.unit, recurrence.interval);
      guard++;
    }
    // Nunca retroceder más allá del ancla real
    if (start.getTime() < anchor.getTime()) start = new Date(anchor);

      // Tope superior: si la serie tiene límite, no existen ocurrencias
      // más allá de su última fecha válida (feature 002).
      const lastOccurrence = Countdown.getLastOccurrence(event);

      // Avanzar desde start, recogiendo todas las ocurrencias en (lastSeen, now]
      let check = Countdown.advanceByRecurrence(start, recurrence.unit, recurrence.interval);
      const fired = [];
      guard = 0;
      while (check.getTime() <= now && guard < 1000) {
        if (lastOccurrence && check.getTime() > lastOccurrence.getTime()) break;
        if (check.getTime() > lastSeen) fired.push(new Date(check));
        check = Countdown.advanceByRecurrence(check, recurrence.unit, recurrence.interval);
        guard++;
      }

      if (fired.length > 0) {
        missed.push({ event, date: fired[fired.length - 1] });
      }
    });

    if (!missed.length) return;

    // Ordenar por fecha más reciente primero
    missed.sort((a, b) => b.date - a.date);

    // Renderizar el listado del banner
    const list = document.getElementById('missed-recurring-list');
    list.innerHTML = '';
    missed.forEach(({ event, date }) => {
      const li = document.createElement('li');
      li.className = 'missed-recurring-item';

      const emoji = document.createElement('span');
      emoji.className = 'missed-recurring-emoji';
      emoji.textContent = event.emoji || '⏳';

      const info = document.createElement('div');
      info.className = 'missed-recurring-info';

      const name = document.createElement('div');
      name.className = 'missed-recurring-name';
      name.textContent = event.name;

      const dateEl = document.createElement('div');
      dateEl.className = 'missed-recurring-date';
      const options = { weekday: 'long', day: 'numeric', month: 'long' };
      let formatted = date.toLocaleDateString('es-ES', options);
      formatted = formatted.charAt(0).toUpperCase() + formatted.slice(1);
      dateEl.textContent = formatted;

      info.appendChild(name);
      info.appendChild(dateEl);
      li.appendChild(emoji);
      li.appendChild(info);
      list.appendChild(li);
    });

    UI.showModal('modal-missed-recurring');
  },

  /**
   * Retrocede una fecha una "unidad x cantidad" según el tipo de recurrencia.
   * Es el opuesto de Countdown.advanceByRecurrence.
   * @param {Date} date
   * @param {'day'|'week'|'month'|'year'} unit
   * @param {number} interval
   * @returns {Date}
   */
  subtractRecurrence(date, unit, interval = 1) {
    const prev = new Date(date);
    switch (unit) {
      case 'day':   prev.setDate(prev.getDate() - interval); break;
      case 'week':  prev.setDate(prev.getDate() - interval * 7); break;
      case 'month': prev.setMonth(prev.getMonth() - interval); break;
      case 'year':  prev.setFullYear(prev.getFullYear() - interval); break;
    }
    return prev;
  },

  /** Renderiza la vista de eventos archivados */
  renderArchivedView() {
    const archived = Storage.getArchived();
    UI.renderArchivedList(archived);
    // Inicializar iconos del empty-state de archivados si no se han inicializado aún
    document.querySelectorAll('#view-archived [data-icon]').forEach((el) => {
      if (!el.querySelector('svg')) setIcon(el, el.dataset.icon);
    });
  },

  /**
   * Restaura un evento archivado a la lista activa.
   * @param {string} id
   */
  restoreArchivedEvent(id) {
    Storage.unarchive(id);
    this.renderArchivedView();
    this.renderAll();
  },

  /** Abre el formulario en modo creación */
  openCreateForm() {
    this.currentEditId = null;
    document.getElementById('form-title').textContent = 'Nuevo evento';
    document.getElementById('btn-delete-event').classList.add('hidden');
    document.getElementById('event-form').reset();
    document.getElementById('event-id').value = '';

    // Defaults
    document.getElementById('event-time').value = '00:00';
    document.getElementById('event-emoji').value = '⏳';
    document.getElementById('event-color').value = COLOR_OPTIONS[0];
    document.getElementById('event-category').value = DEFAULT_CATEGORY_ID;
    document.getElementById('event-repeat-toggle').checked = false;
    document.getElementById('event-recurrence-interval').value = 1;
    document.getElementById('event-recurrence-unit').value = 'year';
    document.getElementById('event-recurrence-end-date').value = '';
    document.getElementById('event-recurrence-max-count').value = '';
    this.toggleRepeatRow(false);
    document.getElementById('event-notify-days').value = 0;
    document.getElementById('event-notify-hours').value = 0;
    document.getElementById('event-notify-minutes').value = 0;

    // Default date: tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    document.getElementById('event-date').value = tomorrow.toISOString().slice(0, 10);

    UI.renderEmojiGrid('⏳');
    UI.renderColorGrid(COLOR_OPTIONS[0]);
    UI.renderCategoryGrid(DEFAULT_CATEGORY_ID);
    this.toggleAdvancedFields(false);
    this.updatePreview();

    UI.showView('view-form', 'right');
  },

  /** Abre el formulario en modo edición */
  openEditForm(id) {
    const event = Storage.getById(id);
    if (!event) return;

    this.currentEditId = id;
    document.getElementById('form-title').textContent = 'Editar evento';
    document.getElementById('btn-delete-event').classList.remove('hidden');

    document.getElementById('event-id').value = event.id;
    document.getElementById('event-name').value = event.name;
    document.getElementById('event-date').value = event.date;
    document.getElementById('event-time').value = event.time || '00:00';
    document.getElementById('event-emoji').value = event.emoji || '⏳';
    document.getElementById('event-color').value = event.color || COLOR_OPTIONS[0];
    document.getElementById('event-category').value = event.category || DEFAULT_CATEGORY_ID;

    const { unit, interval, endDate, maxCount } = Countdown.getRecurrence(event);
    const repeats = unit !== 'none';
    document.getElementById('event-repeat-toggle').checked = repeats;
    document.getElementById('event-recurrence-interval').value = interval;
    document.getElementById('event-recurrence-unit').value = repeats ? unit : 'year';
    this.toggleRepeatRow(repeats); // limpia los límites si no repite
    if (repeats) {
      document.getElementById('event-recurrence-end-date').value = endDate || '';
      document.getElementById('event-recurrence-max-count').value = maxCount || '';
    }

    const notifySeconds = Number(event.notifyBefore) || 0;
    document.getElementById('event-notify-days').value = Math.floor(notifySeconds / 86400);
    document.getElementById('event-notify-hours').value = Math.floor((notifySeconds % 86400) / 3600);
    document.getElementById('event-notify-minutes').value = Math.floor((notifySeconds % 3600) / 60);

    UI.renderEmojiGrid(event.emoji);
    UI.renderColorGrid(event.color);
    UI.renderCategoryGrid(event.category || DEFAULT_CATEGORY_ID);

    // Si el evento ya tiene algo configurado fuera de los valores por
    // defecto, expandimos las opciones avanzadas para que no quede oculto.
    const hasNonDefaultOptions = (event.emoji && event.emoji !== '⏳')
      || (event.color && event.color !== COLOR_OPTIONS[0])
      || (event.category && event.category !== DEFAULT_CATEGORY_ID)
      || repeats
      || notifySeconds > 0;
    this.toggleAdvancedFields(hasNonDefaultOptions);

    this.updatePreview();

    UI.showView('view-form', 'right');
  },

  /** Maneja el envío del formulario (crear o editar) */
  async handleSubmit(e) {
    e.preventDefault();

    const name = document.getElementById('event-name').value.trim();
    const date = document.getElementById('event-date').value;
    const time = document.getElementById('event-time').value || '00:00';
    const emoji = document.getElementById('event-emoji').value || '⏳';
    const color = document.getElementById('event-color').value || COLOR_OPTIONS[0];
    const category = document.getElementById('event-category').value || DEFAULT_CATEGORY_ID;

    const repeats = document.getElementById('event-repeat-toggle').checked;
    const recurrenceUnit = repeats ? document.getElementById('event-recurrence-unit').value : 'none';
    const recurrenceInterval = repeats
      ? Math.max(1, parseInt(document.getElementById('event-recurrence-interval').value, 10) || 1)
      : 1;

    // Límites de fin de serie (opcionales). Vacío → null (serie indefinida).
    const rawEndDate = document.getElementById('event-recurrence-end-date').value;
    const rawMaxCount = document.getElementById('event-recurrence-max-count').value;
    const recurrenceEndDate = repeats && rawEndDate ? rawEndDate : null;
    const parsedMaxCount = parseInt(rawMaxCount, 10);
    const recurrenceMaxCount = repeats && Number.isFinite(parsedMaxCount) && parsedMaxCount > 0
      ? Math.min(parsedMaxCount, 9999)
      : null;

    const notifyDays = Math.max(0, parseInt(document.getElementById('event-notify-days').value, 10) || 0);
    const notifyHours = Math.max(0, parseInt(document.getElementById('event-notify-hours').value, 10) || 0);
    const notifyMinutes = Math.max(0, parseInt(document.getElementById('event-notify-minutes').value, 10) || 0);
    const notifySeconds = notifyDays * 86400 + notifyHours * 3600 + notifyMinutes * 60;
    const notifyBefore = notifySeconds > 0 ? notifySeconds : null;

    if (!name || !date) return;

    // Validación de límites de recurrencia
    if (recurrenceEndDate && recurrenceEndDate < date) {
      alert('La fecha de fin de la repetición no puede ser anterior a la fecha del evento.');
      return;
    }
    if (rawMaxCount !== '' && recurrenceMaxCount === null && repeats) {
      alert('El número máximo de repeticiones debe ser un número entero mayor que 0.');
      return;
    }

    const existing = this.currentEditId ? Storage.getById(this.currentEditId) : null;

    // Si el usuario activa un aviso, pedir permiso de notificaciones
    if (notifyBefore) {
      const permission = await this.requestNotificationPermission();
      if (permission !== 'granted') {
        alert('Para recibir avisos, permite las notificaciones en tu navegador. El evento se guardará sin aviso activo.');
      }
    }

    // Si cambia la fecha/hora o la repetición, reseteamos la marca de "ya notificado"
    const existingRecurrence = existing ? Countdown.getRecurrence(existing) : null;
    const targetChanged = !existing || existing.date !== date || existing.time !== time
      || existingRecurrence.unit !== recurrenceUnit || existingRecurrence.interval !== recurrenceInterval
      || existing.notifyBefore !== notifyBefore;

    const event = {
      id: this.currentEditId || generateId(),
      name,
      date,
      time,
      emoji,
      color,
      category,
      recurrenceUnit,
      recurrenceInterval,
      recurrenceEndDate,
      recurrenceMaxCount,
      notifyBefore,
      _celebrated: existing ? existing._celebrated : false,
      _notifiedKey: targetChanged ? null : (existing ? existing._notifiedKey : null),
    };

    Storage.upsert(event);

    // Si el evento estaba archivado (p. ej. una serie que llegó a su límite)
    // y al editarlo vuelve a tener ocurrencias por delante, se reactiva.
    if (existing && existing.archivedAt && !Countdown.hasElapsed(event)) {
      Storage.unarchive(event.id);
    }

    // Push: programar el aviso nuevo o cancelar el que hubiera (FR-006).
    // Sin await a propósito: guardar el evento no debe esperar a la red.
    if (notifyBefore) {
      Push.scheduleEventNotification(event).catch(() => {});
    } else {
      Push.cancelEventNotification(event.id).catch(() => {});
    }

    this.renderAll();
    UI.showView('view-main', 'left');
  },

  /** Elimina el evento que se está editando */
  deleteCurrentEvent() {
    if (!this.currentEditId) return;
    if (!confirm('¿Eliminar este evento?')) return;

    // Push: cancelar el aviso pendiente antes de perder el id (FR-006).
    Push.cancelEventNotification(this.currentEditId).catch(() => {});

    Storage.remove(this.currentEditId);
    this.currentEditId = null;
    this.renderAll();
    UI.showView('view-main', 'left');
  },

  // ─── NOTIFICACIONES PUSH (feature 005) ───────────────────────────────────

  /** Abre el modal de ajustes de push y pinta su estado actual */
  openPushSettings() {
    this.renderPushSettings();
    UI.showModal('modal-push-settings');
  },

  /**
   * Pinta el estado del modal de push según el entorno:
   * - navegador sin soporte → se explica y no se ofrece activar
   * - app sin configurar (constantes de js/push.js sin rellenar) → se avisa
   * - Safari sin instalar en pantalla de inicio → instrucciones (FR-002)
   * - resto → botón para activar o desactivar
   */
  renderPushSettings() {
    const statusEl = document.getElementById('push-settings-status');
    const explainerEl = document.getElementById('push-settings-explainer');
    const toggleBtn = document.getElementById('btn-push-toggle');

    toggleBtn.classList.remove('hidden');
    toggleBtn.disabled = false;

    if (!Push.isSupported()) {
      statusEl.textContent = 'Este navegador no soporta notificaciones push.';
      explainerEl.textContent = 'Los avisos seguirán funcionando mientras tengas la app abierta.';
      toggleBtn.classList.add('hidden');
      return;
    }

    if (!Push.isConfigured()) {
      statusEl.textContent = 'Las notificaciones push todavía no están configuradas en esta instalación.';
      explainerEl.textContent = 'Falta rellenar la URL del Worker, el token y la clave VAPID en js/push.js.';
      toggleBtn.classList.add('hidden');
      return;
    }

    if (!Push.isInstalledStandalone()) {
      statusEl.textContent = 'Para recibir avisos con la app cerrada, primero añade Next Appointment a tu pantalla de inicio.';
      explainerEl.textContent = 'En iPhone: botón Compartir → "Añadir a pantalla de inicio". Luego abre la app desde ese icono y vuelve aquí. Es una limitación de iOS, no de la app.';
      toggleBtn.classList.add('hidden');
      return;
    }

    if (Push.isEnabled()) {
      statusEl.textContent = '✅ Notificaciones push activadas en este dispositivo.';
      explainerEl.textContent = 'Los avisos que configures en cada evento te llegarán aunque la app esté cerrada.';
      toggleBtn.textContent = 'Desactivar en este dispositivo';
    } else {
      statusEl.textContent = '🔕 Notificaciones push desactivadas en este dispositivo.';
      explainerEl.textContent = 'Si las activas, los avisos llegarán aunque la app esté cerrada. Cada dispositivo se activa por separado.';
      toggleBtn.textContent = 'Activar notificaciones push';
    }
  },

  /** Activa o desactiva push en este dispositivo desde el modal */
  async togglePush() {
    const toggleBtn = document.getElementById('btn-push-toggle');
    toggleBtn.disabled = true;

    if (Push.isEnabled()) {
      toggleBtn.textContent = 'Desactivando…';
      await Push.unsubscribeFromPush();
      this.renderPushSettings();
      return;
    }

    toggleBtn.textContent = 'Activando…';
    const result = await Push.subscribeToPush();

    if (result.ok) {
      // Programa de una vez los avisos de los eventos que ya existían.
      await Push.resyncAll(Storage.getActive());
      this.renderPushSettings();
      document.getElementById('push-settings-explainer').textContent =
        'Listo. Tus eventos con aviso ya están programados en este dispositivo.';
      return;
    }

    this.renderPushSettings();
    const messages = {
      denied: 'No diste permiso de notificaciones. Puedes cambiarlo en Ajustes → Notificaciones → Next Appointment.',
      'not-standalone': 'Añade la app a tu pantalla de inicio y ábrela desde ahí para poder activar el push.',
      'not-configured': 'Faltan los datos del Worker en js/push.js.',
      'worker-error': 'No se pudo registrar el dispositivo en el servidor de avisos. Inténtalo de nuevo más tarde.',
      unsupported: 'Este navegador no soporta notificaciones push.',
    };
    document.getElementById('push-settings-explainer').textContent =
      messages[result.reason] || 'No se pudo activar el push. Inténtalo de nuevo.';
  },

  /** Muestra u oculta el bloque de cantidad+unidad de repetición */
  toggleRepeatRow(show) {
    document.getElementById('repeat-row').hidden = !show;
    document.getElementById('repeat-limit-row').hidden = !show;
    document.getElementById('repeat-hint').hidden = !show;

    // Al desactivar "Repetir", los límites dejan de tener sentido
    if (!show) {
      document.getElementById('event-recurrence-end-date').value = '';
      document.getElementById('event-recurrence-max-count').value = '';
    }
  },

  /**
   * Muestra u oculta el bloque de campos avanzados (icono, color,
   * categoría, repetir, aviso) del modo rápido de creación.
   * @param {boolean} show
   */
  toggleAdvancedFields(show) {
    document.getElementById('advanced-fields').hidden = !show;
    document.getElementById('advanced-collapsed-hint').hidden = show;
    const btn = document.getElementById('btn-toggle-advanced');
    btn.setAttribute('aria-expanded', String(show));
    document.getElementById('advanced-toggle-label').textContent = show
      ? 'Ocultar opciones'
      : 'Más opciones (icono, color, categoría...)';
  },

  /** Actualiza la card de vista previa del formulario */
  updatePreview() {
    const name = document.getElementById('event-name').value.trim() || 'Nombre del evento';
    const date = document.getElementById('event-date').value;
    const time = document.getElementById('event-time').value || '00:00';
    const emoji = document.getElementById('event-emoji').value || '⏳';
    const color = document.getElementById('event-color').value || COLOR_OPTIONS[0];
    const repeats = document.getElementById('event-repeat-toggle')?.checked || false;
    const recurrenceUnit = repeats ? (document.getElementById('event-recurrence-unit')?.value || 'year') : 'none';
    const recurrenceInterval = repeats
      ? Math.max(1, parseInt(document.getElementById('event-recurrence-interval')?.value, 10) || 1)
      : 1;

    document.getElementById('preview-emoji').textContent = emoji;
    document.getElementById('preview-name').textContent = name;
    document.getElementById('preview-card').style.setProperty('--accent-color', color);

    if (!date) {
      document.getElementById('preview-countdown').textContent = '--d --h --m --s';
      document.getElementById('preview-date').textContent = 'Selecciona una fecha';
      return;
    }

    const rawEndDate = document.getElementById('event-recurrence-end-date')?.value || '';
    const parsedMax = parseInt(document.getElementById('event-recurrence-max-count')?.value, 10);
    const tempEvent = {
      date,
      time,
      recurrenceUnit,
      recurrenceInterval,
      recurrenceEndDate: repeats && rawEndDate ? rawEndDate : null,
      recurrenceMaxCount: repeats && Number.isFinite(parsedMax) && parsedMax > 0 ? parsedMax : null,
    };
    document.getElementById('preview-date').textContent = Countdown.formatDate(tempEvent);

    if (Countdown.hasElapsed(tempEvent)) {
      document.getElementById('preview-countdown').textContent = '🎉 ¡Ya llegó!';
    } else {
      const { days, hours, minutes, seconds } = Countdown.breakdown(Countdown.diffMs(tempEvent));
      document.getElementById('preview-countdown').textContent =
        `${days}d ${pad(hours)}h ${pad(minutes)}m ${pad(seconds)}s`;
    }
  },

  /** Abre el modal de compartir con un enlace que el destinatario puede importar */
  shareEvent(id) {
    const event = Storage.getById(id);
    if (!event) return;

    const encoded = encodeEventForShare(event);
    const url = new URL(window.location.href);
    url.search = '';
    url.hash = '';
    url.searchParams.set('import', encoded);

    this.pendingShareUrl = url.toString();

    const input = document.getElementById('share-link-input');
    input.value = this.pendingShareUrl;

    const nativeBtn = document.getElementById('btn-share-native');
    if (navigator.share) {
      nativeBtn.classList.remove('hidden');
    } else {
      nativeBtn.classList.add('hidden');
    }

    UI.showModal('modal-share');
  },

  /** Copia el enlace de compartir al portapapeles */
  copyShareLink() {
    const input = document.getElementById('share-link-input');
    input.select();

    if (navigator.clipboard) {
      navigator.clipboard.writeText(input.value).then(() => {
        const btn = document.getElementById('btn-copy-link');
        const original = btn.textContent;
        btn.textContent = '¡Copiado!';
        setTimeout(() => { btn.textContent = original; }, 1500);
      });
    } else {
      document.execCommand('copy');
    }
  },

  /** Usa la Web Share API nativa para compartir el enlace */
  nativeShareLink() {
    if (!navigator.share || !this.pendingShareUrl) return;
    navigator.share({ url: this.pendingShareUrl }).catch(() => {});
  },

  /**
   * Comprueba si la URL actual contiene un evento compartido (?import=...)
   * y, si es así, muestra el modal de importación.
   */
  checkForSharedEvent() {
    const params = new URLSearchParams(window.location.search);
    const encoded = params.get('import');
    if (!encoded) return;

    this.tryShowImportPreview(encoded, { cleanUrl: true });
  },

  /**
   * Extrae el código base64 a partir de lo que el usuario haya pegado:
   * puede ser una URL completa con ?import=..., o solo el código.
   * @param {string} rawInput
   * @returns {string|null}
   */
  extractEncodedFromInput(rawInput) {
    const trimmed = (rawInput || '').trim();
    if (!trimmed) return null;

    // ¿Es una URL? intentamos extraer el parámetro "import"
    try {
      const url = new URL(trimmed);
      const fromUrl = url.searchParams.get('import');
      if (fromUrl) return fromUrl;
    } catch (e) {
      // No es una URL válida, seguimos asumiendo que es el código directo
    }

    // Si parece contener "import=" sin ser una URL completa (ej. pegaron solo la query)
    const match = trimmed.match(/import=([^&\s]+)/);
    if (match) return decodeURIComponent(match[1]);

    // Asumimos que el texto pegado es directamente el código
    return trimmed;
  },

  /**
   * Decodifica un código y, si es válido, muestra el modal de preview de import.
   * @param {string} encoded
   * @param {{cleanUrl?: boolean}} options
   * @returns {boolean} true si se pudo decodificar y mostrar
   */
  tryShowImportPreview(encoded, options = {}) {
    const decoded = decodeSharedEvent(encoded);
    if (!decoded) return false;

    this.pendingImport = decoded;

    document.getElementById('import-emoji').textContent = decoded.emoji;
    document.getElementById('import-name').textContent = decoded.name;
    document.getElementById('import-date').textContent = Countdown.formatDate(decoded);

    UI.showModal('modal-import');

    if (options.cleanUrl) this.cleanImportFromUrl();

    return true;
  },

  /** Abre el modal para pegar manualmente un enlace o código de evento compartido */
  openPasteImportModal() {
    document.getElementById('paste-import-input').value = '';
    document.getElementById('paste-import-error').classList.add('hidden');
    UI.showModal('modal-paste-import');
    setTimeout(() => document.getElementById('paste-import-input').focus(), 50);
  },

  /** Confirma el contenido pegado: puede ser JSON masivo, enlace o código base64 */
  confirmPasteImport() {
    const raw = document.getElementById('paste-import-input').value.trim();
    const errorEl = document.getElementById('paste-import-error');
    errorEl.classList.add('hidden');

    if (!raw) {
      errorEl.classList.remove('hidden');
      return;
    }

    UI.hideModal('modal-paste-import');
    const success = this._handleImportText(raw);

    if (!success) {
      // Vuelve a mostrar el modal con el error
      document.getElementById('paste-import-input').value = raw;
      errorEl.classList.remove('hidden');
      UI.showModal('modal-paste-import');
    }
  },

  /** Acepta el evento importado y lo añade a los eventos del usuario */
  acceptImport() {
    if (!this.pendingImport) return;

    const event = {
      id: generateId(),
      name: this.pendingImport.name,
      date: this.pendingImport.date,
      time: this.pendingImport.time,
      emoji: this.pendingImport.emoji,
      color: this.pendingImport.color,
      category: this.pendingImport.category || DEFAULT_CATEGORY_ID,
      recurrenceUnit: this.pendingImport.recurrenceUnit || 'none',
      recurrenceInterval: this.pendingImport.recurrenceInterval || 1,
      notifyBefore: null,
      _celebrated: false,
      _notifiedKey: null,
    };

    Storage.upsert(event);
    this.pendingImport = null;
    UI.hideModal('modal-import');
    this.renderAll();
  },

  /** Descarta el evento importado sin guardarlo */
  dismissImport() {
    this.pendingImport = null;
    UI.hideModal('modal-import');
  },

  /** Elimina el parámetro ?import= de la URL sin recargar la página */
  cleanImportFromUrl() {
    const url = new URL(window.location.href);
    url.searchParams.delete('import');
    window.history.replaceState({}, '', url.toString());
  },

  /** Registra el service worker (si está disponible) */
  registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('service-worker.js').catch((err) => {
        console.warn('Service worker no registrado:', err);
      });
    }
  },

  // ─── EXPORTAR ────────────────────────────────────────────────────────────

  /** Abre el modal de exportación mostrando cuántos eventos se van a exportar */
  openExportModal() {
    const events = Storage.getActive();
    const count = events.length;
    document.getElementById('export-count').textContent =
      count === 0 ? 'No tienes eventos activos para exportar.'
      : count === 1 ? '1 evento activo se incluirá en la exportación.'
      : `${count} eventos activos se incluirán en la exportación.`;
    UI.showModal('modal-export');
  },

  /** Genera el JSON de exportación (solo eventos activos, sin flags internos) */
  _buildExportJson() {
    const events = Storage.getActive().map((e) => {
      const { unit, interval, endDate, maxCount } = Countdown.getRecurrence(e);
      return {
        id: e.id,
        name: e.name,
        date: e.date,
        time: e.time || '00:00',
        emoji: e.emoji || '⏳',
        color: e.color || '#6c5ce7',
        category: e.category || 'other',
        recurrenceUnit: unit,
        recurrenceInterval: interval,
        recurrenceEndDate: endDate,
        recurrenceMaxCount: maxCount,
        notifyBefore: e.notifyBefore || null,
      };
    });
    return JSON.stringify({ version: 1, app: 'next-appointment', events }, null, 2);
  },

  /** Descarga un archivo .json con todos los eventos activos */
  exportAsJson() {
    const json = this._buildExportJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const date = new Date().toISOString().slice(0, 10);
    a.download = `next-appointment-${date}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    const btn = document.getElementById('btn-export-download');
    const original = btn.textContent;
    btn.textContent = '✅ Descargado';
    setTimeout(() => { btn.textContent = original; }, 2000);
  },

  /** Copia el JSON de exportación al portapapeles */
  exportToClipboard() {
    const json = this._buildExportJson();
    const btn = document.getElementById('btn-export-clipboard');
    const original = btn.textContent;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(json).then(() => {
        btn.textContent = '✅ Copiado';
        setTimeout(() => { btn.textContent = original; }, 2000);
      }).catch(() => {
        btn.textContent = '❌ Error al copiar';
        setTimeout(() => { btn.textContent = original; }, 2000);
      });
    } else {
      const ta = document.createElement('textarea');
      ta.value = json;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      btn.textContent = '✅ Copiado';
      setTimeout(() => { btn.textContent = original; }, 2000);
    }
  },

  // ─── IMPORTAR JSON ────────────────────────────────────────────────────────

  /**
   * Intenta parsear texto pegado o cargado desde archivo.
   * Si es JSON de exportación → flujo de importación masiva.
   * Si es enlace/código base64 → flujo individual existente.
   */
  _tryParseExportJson(text) {
    try {
      const data = JSON.parse(text);
      if (data && data.app === 'next-appointment' && Array.isArray(data.events)) {
        return data.events;
      }
    } catch (e) { /* no es JSON */ }
    return null;
  },

  /** Lee un archivo .json seleccionado desde el file picker */
  importFromFile(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      UI.hideModal('modal-paste-import');
      this._handleImportText(text);
    };
    reader.onerror = () => {
      document.getElementById('paste-import-error').classList.remove('hidden');
    };
    reader.readAsText(file);
  },

  /**
   * Enruta el texto importado: JSON masivo o enlace/código individual.
   * @param {string} text
   * @returns {boolean} true si se pudo procesar
   */
  _handleImportText(text) {
    const bulkEvents = this._tryParseExportJson(text);
    if (bulkEvents) {
      this._showBulkJsonImportModal(bulkEvents);
      return true;
    }

    // Fallback: intenta como enlace/código individual
    const encoded = this.extractEncodedFromInput(text);
    if (encoded) {
      const success = this.tryShowImportPreview(encoded);
      if (success) return true;
    }

    return false;
  },

  /** Muestra el modal de confirmación de importación masiva */
  _showBulkJsonImportModal(events) {
    this._pendingBulkImport = events;
    const existing = new Set(Storage.getAll().map((e) => e.id));
    const newCount = events.filter((e) => !existing.has(e.id)).length;
    const skipCount = events.length - newCount;

    let summary = `El archivo contiene ${events.length} evento${events.length !== 1 ? 's' : ''}.`;
    if (newCount > 0) summary += ` Se añadirán ${newCount} nuevo${newCount !== 1 ? 's' : ''}.`;
    if (skipCount > 0) summary += ` Se omitirán ${skipCount} ya existente${skipCount !== 1 ? 's' : ''}.`;

    document.getElementById('import-json-summary').textContent = summary;
    UI.showModal('modal-import-json');
  },

  /** Acepta e importa todos los eventos del JSON (omite duplicados por ID) */
  acceptBulkJsonImport() {
    if (!this._pendingBulkImport) return;

    const existing = new Set(Storage.getAll().map((e) => e.id));
    const VALID_UNITS = ['none', 'day', 'week', 'month', 'year'];
    let imported = 0;

    this._pendingBulkImport.forEach((raw) => {
      if (existing.has(raw.id)) return; // omitir duplicados
      if (!raw.name || !raw.date) return; // datos mínimos obligatorios

      const event = {
        id: raw.id || generateId(),
        name: String(raw.name).slice(0, 40),
        date: raw.date,
        time: raw.time || '00:00',
        emoji: raw.emoji || '⏳',
        color: raw.color || '#6c5ce7',
        category: raw.category || 'other',
        recurrenceUnit: VALID_UNITS.includes(raw.recurrenceUnit) ? raw.recurrenceUnit : 'none',
        recurrenceInterval: Math.max(1, Number(raw.recurrenceInterval) || 1),
        // Ausentes en backups anteriores a la feature 002 → serie indefinida
        recurrenceEndDate: raw.recurrenceEndDate || null,
        recurrenceMaxCount: Number(raw.recurrenceMaxCount) > 0
          ? Math.min(Math.floor(Number(raw.recurrenceMaxCount)), 9999)
          : null,
        notifyBefore: raw.notifyBefore || null,
        _celebrated: false,
        _notifiedKey: null,
      };

      Storage.upsert(event);
      imported++;
    });

    this._pendingBulkImport = null;
    UI.hideModal('modal-import-json');
    this.renderAll();

    if (imported > 0) {
      alert(`✅ ${imported} evento${imported !== 1 ? 's' : ''} importado${imported !== 1 ? 's' : ''} correctamente.`);
    }
  },
};

document.addEventListener('DOMContentLoaded', () => App.init());
