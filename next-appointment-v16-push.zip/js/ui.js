/* =========================================
   Next Appointment — UI rendering helpers
   ========================================= */

const EMOJI_OPTIONS = [
  '⏳', '🎂', '✈️', '🎓', '🎬', '💒', '🏠', '🍾',
  '💼', '🎮', '🎉', '❤️', '🌴', '🎄', '🐣', '🎁',
];

const COLOR_OPTIONS = [
  '#6c5ce7', '#e17055', '#00b894', '#0984e3',
  '#fdcb6e', '#e84393', '#2d3436', '#00cec9',
];

/**
 * ⚠️ ÚNICO LUGAR A EDITAR para añadir, quitar o renombrar categorías.
 * Cada categoría es { id, label, emoji }.
 * - "id" se guarda en los eventos y NO debe cambiarse una vez en uso
 *   (si lo cambias, los eventos ya creados con ese id quedarán como "Otros").
 * - "label" es el texto visible, se puede cambiar libremente.
 * - "emoji" se usa como icono en los chips de filtro.
 * El id 'other' siempre debe existir: es el valor por defecto/fallback.
 */
const CATEGORIES = [
  { id: 'birthday', label: 'Cumpleaños', emoji: '🎂' },
  { id: 'health', label: 'Salud', emoji: '🩺' },
  { id: 'party', label: 'Fiestas', emoji: '🎉' },
  { id: 'fair', label: 'Ferias', emoji: '🎪' },
  { id: 'festival', label: 'Festivales', emoji: '🎶' },
  { id: 'travel', label: 'Viajes', emoji: '✈️' },
  { id: 'other', label: 'Otros', emoji: '⏳' },
];

const DEFAULT_CATEGORY_ID = 'other';

/**
 * Devuelve el objeto de categoría a partir de su id, con fallback a "Otros".
 * @param {string} id
 */
function getCategoryById(id) {
  return CATEGORIES.find((c) => c.id === id) || CATEGORIES.find((c) => c.id === DEFAULT_CATEGORY_ID);
}

/**
 * Devuelve la etiqueta corta visible para una recurrencia { unit, interval }.
 * Con interval 1 usa la forma simple ("Diario", "Anual"...), y con
 * interval > 1 usa la forma "Cada N unidad(es)" (ej. "Cada 3 días").
 * @param {{unit: 'none'|'day'|'week'|'month'|'year', interval: number}} recurrence
 */
function recurrenceLabel(recurrence) {
  const { unit, interval, endDate, maxCount } = recurrence;
  if (!unit || unit === 'none') return '';

  let label;
  if (interval === 1) {
    switch (unit) {
      case 'day': label = 'Diario'; break;
      case 'week': label = 'Semanal'; break;
      case 'month': label = 'Mensual'; break;
      case 'year': label = 'Anual'; break;
      default: return '';
    }
  } else {
    const UNIT_PLURAL = { day: 'días', week: 'semanas', month: 'meses', year: 'años' };
    label = `Cada ${interval} ${UNIT_PLURAL[unit] || ''}`;
  }

  // Sufijos de límite de serie (feature 002). Sin límites, el label no cambia.
  if (maxCount) label += ` · ${maxCount} rep${maxCount !== 1 ? 's' : ''}`;
  if (endDate) label += ` · hasta ${formatShortDate(endDate)}`;

  return label;
}

/**
 * Formatea 'YYYY-MM-DD' como "30 nov" para los sufijos de límite.
 * @param {string} isoDate
 */
function formatShortDate(isoDate) {
  const d = new Date(`${isoDate}T00:00:00`);
  if (Number.isNaN(d.getTime())) return isoDate;
  return d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }).replace('.', '');
}

const UI = {
  /**
   * Cambia la vista activa, con una transición de slide.
   * @param {string} viewId
   * @param {'left'|'right'|null} direction - dirección de la animación de entrada
   */
  showView(viewId, direction = 'right') {
    document.querySelectorAll('.view').forEach((el) => {
      el.classList.remove('view-active', 'view-slide-in-right', 'view-slide-in-left');
    });
    const target = document.getElementById(viewId);
    if (target) {
      target.classList.add('view-active');
      if (direction === 'left') {
        target.classList.add('view-slide-in-left');
      } else if (direction === 'right') {
        target.classList.add('view-slide-in-right');
      }
    }
    window.scrollTo(0, 0);
  },

  /**
   * Aplica el tema (light/dark) al documento.
   * @param {'light'|'dark'} theme
   */
  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const btn = document.getElementById('btn-theme');
    if (btn) setIcon(btn, theme === 'dark' ? 'sun' : 'moon');
  },

  /**
   * Renderiza el carrusel principal con todas las cards de eventos.
   * @param {Array<Object>} events
   */
  renderCarousel(events) {
    const carousel = document.getElementById('event-carousel');
    const dotsContainer = document.getElementById('carousel-dots');
    const emptyState = document.getElementById('empty-state');

    carousel.innerHTML = '';
    dotsContainer.innerHTML = '';

    if (!events.length) {
      emptyState.classList.remove('hidden');
      carousel.classList.add('hidden');
      dotsContainer.classList.add('hidden');
      return;
    }

    emptyState.classList.add('hidden');
    carousel.classList.remove('hidden');
    dotsContainer.classList.remove('hidden');

    const sorted = [...events].sort(
      (a, b) => Countdown.diffMs(a) - Countdown.diffMs(b)
    );

    sorted.forEach((event, i) => {
      carousel.appendChild(this.buildEventCard(event));

      const dot = document.createElement('div');
      dot.className = 'dot' + (i === 0 ? ' active' : '');
      dotsContainer.appendChild(dot);
    });

    // Sync dots with scroll position (el gesto de swipe lo gestiona
    // el navegador de forma nativa vía scroll-snap en CSS; aquí solo
    // escuchamos el scroll para mantener los puntos sincronizados)
    carousel.onscroll = () => {
      const index = Math.round(carousel.scrollLeft / carousel.clientWidth);
      [...dotsContainer.children].forEach((dot, i) => {
        dot.classList.toggle('active', i === index);
      });
    };
  },

  /**
   * Crea el elemento DOM de una card de evento (vista principal).
   * @param {Object} event
   */
  buildEventCard(event) {
    const card = document.createElement('div');
    card.className = 'event-card';
    card.style.setProperty('--accent-color', event.color || '#6c5ce7');
    card.dataset.id = event.id;

    const elapsed = Countdown.hasElapsed(event);
    if (elapsed) card.classList.add('elapsed');

    const category = getCategoryById(event.category);
    const categoryBadge = document.createElement('div');
    categoryBadge.className = 'card-category-badge';
    categoryBadge.textContent = `${category.emoji} ${category.label}`;
    card.appendChild(categoryBadge);

    if (event.isOnboardingExample) {
      const exampleBadge = document.createElement('div');
      exampleBadge.className = 'card-badge card-example-badge';
      exampleBadge.textContent = 'Ejemplo';
      card.appendChild(exampleBadge);
    }

    const recurrence = Countdown.getRecurrence(event);
    if (recurrence.unit !== 'none') {
      const badge = document.createElement('div');
      badge.className = 'card-badge';
      badge.textContent = `🔁 ${recurrenceLabel(recurrence)}`;
      card.appendChild(badge);
    }

    const emoji = document.createElement('div');
    emoji.className = 'card-emoji';
    emoji.textContent = event.emoji || '⏳';
    card.appendChild(emoji);

    const name = document.createElement('div');
    name.className = 'card-name';
    name.textContent = event.name;
    card.appendChild(name);

    const countdownWrap = document.createElement('div');
    countdownWrap.className = 'card-countdown-units';
    countdownWrap.dataset.role = 'countdown';
    card.appendChild(countdownWrap);

    const date = document.createElement('div');
    date.className = 'card-date';
    date.textContent = Countdown.formatDate(event);
    card.appendChild(date);

    const actions = document.createElement('div');
    actions.className = 'card-actions';

    const editBtn = document.createElement('button');
    editBtn.className = 'icon-btn';
    setIcon(editBtn, 'pencil');
    editBtn.setAttribute('aria-label', 'Editar');
    editBtn.onclick = () => App.openEditForm(event.id);
    actions.appendChild(editBtn);

    const shareBtn = document.createElement('button');
    shareBtn.className = 'icon-btn';
    setIcon(shareBtn, 'share');
    shareBtn.setAttribute('aria-label', 'Compartir');
    shareBtn.onclick = () => App.shareEvent(event.id);
    actions.appendChild(shareBtn);

    const notifyBtn = document.createElement('button');
    notifyBtn.className = 'icon-btn';
    setIcon(notifyBtn, event.notifyBefore ? 'bell' : 'bellOff');
    if (event.notifyBefore) notifyBtn.classList.add('notify-active');
    notifyBtn.setAttribute('aria-label', 'Aviso');
    notifyBtn.onclick = () => App.openEditForm(event.id);
    actions.appendChild(notifyBtn);

    card.appendChild(actions);

    if (event.isOnboardingExample) {
      const ownEventBtn = document.createElement('button');
      ownEventBtn.type = 'button';
      ownEventBtn.className = 'btn-primary card-own-event-btn';
      ownEventBtn.textContent = 'Crear mi propio evento';
      ownEventBtn.onclick = () => App.replaceOnboardingWithOwnEvent();
      card.appendChild(ownEventBtn);
    }

    this.updateCardCountdown(card, event);

    return card;
  },

  /**
   * Actualiza los números del countdown dentro de una card.
   * @param {HTMLElement} card
   * @param {Object} event
   */
  updateCardCountdown(card, event) {
    const wrap = card.querySelector('[data-role="countdown"]');
    if (!wrap) return;

    if (Countdown.hasElapsed(event)) {
      wrap.innerHTML = '<div class="card-countdown">🎉 ¡Ya llegó el día!</div>';
      return;
    }

    const ms = Countdown.diffMs(event);
    const { days, hours, minutes, seconds } = Countdown.breakdown(ms);

    wrap.innerHTML = '';
    const units = [
      { value: days, label: 'Días' },
      { value: hours, label: 'Horas' },
      { value: minutes, label: 'Min' },
      { value: seconds, label: 'Seg' },
    ];

    units.forEach((u) => {
      const unitEl = document.createElement('div');
      unitEl.className = 'countdown-unit';

      const value = document.createElement('div');
      value.className = 'countdown-value';
      value.textContent = String(u.value).padStart(2, '0');

      const label = document.createElement('div');
      label.className = 'countdown-label';
      label.textContent = u.label;

      unitEl.appendChild(value);
      unitEl.appendChild(label);
      wrap.appendChild(unitEl);
    });
  },

  /**
   * Ordena eventos según el modo elegido.
   * @param {Array<Object>} events
   * @param {string} sortMode
   * @returns {Array<Object>}
   */
  sortEvents(events, sortMode) {
    const list = [...events];
    switch (sortMode) {
      case 'date-desc':
        return list.sort((a, b) => Countdown.diffMs(b) - Countdown.diffMs(a));
      case 'name':
        return list.sort((a, b) => a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }));
      case 'created':
        return list.sort((a, b) => {
          const aTime = parseInt((a.id || '').split('_')[1] || '0', 36);
          const bTime = parseInt((b.id || '').split('_')[1] || '0', 36);
          return bTime - aTime;
        });
      case 'date-asc':
      default:
        return list.sort((a, b) => Countdown.diffMs(a) - Countdown.diffMs(b));
    }
  },

  /**
   * Marca el chip de ordenación activo.
   * @param {string} sortMode
   */
  renderSortBar(sortMode) {
    document.querySelectorAll('.sort-chip').forEach((chip) => {
      chip.classList.toggle('active', chip.dataset.sort === sortMode);
    });
  },

  /**
   * Filtra eventos por categoría y/o texto de búsqueda (por nombre).
   * Centraliza la lógica para que carrusel, lista y el tick en vivo
   * apliquen siempre el mismo criterio.
   * @param {Array<Object>} events
   * @param {string} categoryFilter - 'all' o id de categoría
   * @param {string} searchQuery - texto a buscar en el nombre (insensible a mayúsculas/acentos)
   * @returns {Array<Object>}
   */
  filterEvents(events, categoryFilter = 'all', searchQuery = '') {
    let result = categoryFilter === 'all'
      ? events
      : events.filter((e) => (e.category || DEFAULT_CATEGORY_ID) === categoryFilter);

    const query = (searchQuery || '').trim().toLowerCase();
    if (query) {
      const normalize = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
      const normalizedQuery = normalize(query);
      result = result.filter((e) => normalize(e.name || '').includes(normalizedQuery));
    }

    return result;
  },

  /**
   * Renderiza la lista completa de eventos (vista lista).
   * @param {Array<Object>} events
   * @param {string} sortMode - 'date-asc' | 'date-desc' | 'name' | 'created'
   * @param {string} categoryFilter - 'all' o id de categoría
   * @param {string} searchQuery - texto de búsqueda por nombre
   */
  /**
   * Configura el icono, título, subtítulo y botón del estado vacío de la
   * lista según el contexto: sin búsqueda con resultados, sin eventos en
   * la categoría activa, o sin eventos en absoluto.
   * @param {Array<Object>} allEvents - todos los eventos sin filtrar (para distinguir los casos)
   * @param {string} categoryFilter
   * @param {string} searchQuery
   */
  renderListEmptyVariant(allEvents, categoryFilter, searchQuery) {
    const iconEl = document.getElementById('list-empty-icon');
    const titleEl = document.getElementById('list-empty-title');
    const subtitleEl = document.getElementById('list-empty-subtitle');
    const actionBtn = document.getElementById('btn-list-empty-action');

    const query = (searchQuery || '').trim();

    if (query) {
      // Caso: búsqueda sin resultados
      setIcon(iconEl, 'searchOff');
      iconEl.classList.add('empty-icon-circle-muted');
      titleEl.textContent = 'Sin resultados';
      subtitleEl.textContent = `Nada coincide con "${query}".`;
      actionBtn.classList.add('hidden');
    } else if (categoryFilter !== 'all') {
      // Caso: categoría activa sin eventos
      const category = getCategoryById(categoryFilter);
      setIcon(iconEl, 'moodEmpty');
      iconEl.classList.add('empty-icon-circle-muted');
      titleEl.textContent = 'Nada por aquí';
      subtitleEl.textContent = `No tienes eventos en "${category.label}" todavía.`;
      actionBtn.textContent = 'Ver todas las categorías';
      actionBtn.classList.remove('hidden');
      actionBtn.onclick = () => App.setActiveCategory('all');
    } else {
      // Caso: sin eventos en absoluto
      setIcon(iconEl, 'hourglassEmpty');
      iconEl.classList.remove('empty-icon-circle-muted');
      titleEl.textContent = 'Nada en el horizonte todavía';
      subtitleEl.textContent = 'No hay eventos creados todavía.';
      actionBtn.classList.add('hidden');
    }
  },

  renderList(events, sortMode = 'date-asc', categoryFilter = 'all', searchQuery = '') {
    const list = document.getElementById('event-list');
    const emptyState = document.getElementById('list-empty-state');

    list.innerHTML = '';

    const filtered = this.filterEvents(events, categoryFilter, searchQuery);

    if (!filtered.length) {
      emptyState.classList.remove('hidden');
      this.renderListEmptyVariant(events, categoryFilter, searchQuery);
      return;
    }
    emptyState.classList.add('hidden');

    const sorted = this.sortEvents(filtered, sortMode);

    sorted.forEach((event) => {
      const li = document.createElement('li');
      li.className = 'event-list-item';
      li.onclick = () => App.openEditForm(event.id);

      const emoji = document.createElement('div');
      emoji.className = 'event-list-emoji';
      emoji.style.background = (event.color || '#6c5ce7') + '22';
      emoji.textContent = event.emoji || '⏳';

      const info = document.createElement('div');
      info.className = 'event-list-info';

      const name = document.createElement('div');
      name.className = 'event-list-name';
      name.textContent = event.isOnboardingExample ? `${event.name} (Ejemplo)` : event.name;

      const category = getCategoryById(event.category);
      const recurrence = Countdown.getRecurrence(event);
      const categoryTag = document.createElement('span');
      categoryTag.className = 'event-list-category';
      categoryTag.textContent = recurrence.unit !== 'none'
        ? `${category.emoji} ${category.label} · 🔁 ${recurrenceLabel(recurrence)}`
        : `${category.emoji} ${category.label}`;

      const date = document.createElement('div');
      date.className = 'event-list-date';
      date.textContent = Countdown.formatDate(event);

      info.appendChild(name);
      info.appendChild(categoryTag);
      info.appendChild(date);

      const countdown = document.createElement('div');
      countdown.className = 'event-list-countdown';
      countdown.style.color = event.color || '#6c5ce7';
      countdown.textContent = Countdown.shortLabel(event);

      li.appendChild(emoji);
      li.appendChild(info);
      li.appendChild(countdown);

      list.appendChild(li);
    });
  },

  /**
   * Renderiza la lista de eventos archivados, con botón de restaurar
   * en cada uno. Ordenados por fecha de archivado, más reciente primero.
   * @param {Array<Object>} archivedEvents
   */
  renderArchivedList(archivedEvents) {
    const list = document.getElementById('archived-list');
    const emptyState = document.getElementById('archived-empty-state');

    list.innerHTML = '';

    if (!archivedEvents.length) {
      emptyState.classList.remove('hidden');
      return;
    }
    emptyState.classList.add('hidden');

    const sorted = [...archivedEvents].sort((a, b) => (b.archivedAt || 0) - (a.archivedAt || 0));

    sorted.forEach((event) => {
      const li = document.createElement('li');
      li.className = 'event-list-item archived-list-item';

      const emoji = document.createElement('div');
      emoji.className = 'event-list-emoji';
      emoji.style.background = (event.color || '#6c5ce7') + '22';
      emoji.textContent = event.emoji || '⏳';

      const info = document.createElement('div');
      info.className = 'event-list-info';

      const name = document.createElement('div');
      name.className = 'event-list-name';
      name.textContent = event.name;

      const category = getCategoryById(event.category);
      const categoryTag = document.createElement('span');
      categoryTag.className = 'event-list-category';
      categoryTag.textContent = `${category.emoji} ${category.label}`;

      const date = document.createElement('div');
      date.className = 'event-list-date';
      date.textContent = Countdown.formatDate(event);

      const daysLeft = event.archivedAt
        ? Math.max(0, 30 - Math.floor((Date.now() - event.archivedAt) / 86400000))
        : 30;
      const archivedNote = document.createElement('div');
      archivedNote.className = 'event-list-category';
      archivedNote.textContent = daysLeft > 0
        ? `Se eliminará en ${daysLeft} día${daysLeft === 1 ? '' : 's'}`
        : 'Se eliminará pronto';

      info.appendChild(name);
      info.appendChild(categoryTag);
      info.appendChild(date);
      info.appendChild(archivedNote);

      const restoreBtn = document.createElement('button');
      restoreBtn.type = 'button';
      restoreBtn.className = 'archived-restore-btn';
      restoreBtn.setAttribute('aria-label', 'Restaurar evento');
      setIcon(restoreBtn, 'rotateCcw');
      restoreBtn.onclick = (e) => {
        e.stopPropagation();
        App.restoreArchivedEvent(event.id);
      };

      li.appendChild(emoji);
      li.appendChild(info);
      li.appendChild(restoreBtn);

      list.appendChild(li);
    });
  },

  /**
   * Renderiza el grid de selección de emoji en el formulario.
   * @param {string} selected
   */
  renderEmojiGrid(selected) {
    const grid = document.getElementById('emoji-grid');
    grid.innerHTML = '';

    EMOJI_OPTIONS.forEach((emoji) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'emoji-option' + (emoji === selected ? ' selected' : '');
      btn.textContent = emoji;
      btn.onclick = () => {
        document.getElementById('event-emoji').value = emoji;
        grid.querySelectorAll('.emoji-option').forEach((el) => el.classList.remove('selected'));
        btn.classList.add('selected');
        App.updatePreview();
      };
      grid.appendChild(btn);
    });
  },

  /**
   * Renderiza el grid de selección de color en el formulario.
   * @param {string} selected
   */
  renderColorGrid(selected) {
    const grid = document.getElementById('color-grid');
    grid.innerHTML = '';

    COLOR_OPTIONS.forEach((color) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'color-option' + (color === selected ? ' selected' : '');
      btn.style.background = color;
      btn.onclick = () => {
        document.getElementById('event-color').value = color;
        grid.querySelectorAll('.color-option').forEach((el) => el.classList.remove('selected'));
        btn.classList.add('selected');
        App.updatePreview();
      };
      grid.appendChild(btn);
    });
  },

  /**
   * Renderiza el grid de selección de categoría en el formulario.
   * @param {string} selected - id de categoría
   */
  renderCategoryGrid(selected) {
    const grid = document.getElementById('category-grid');
    grid.innerHTML = '';

    CATEGORIES.forEach((cat) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'category-option' + (cat.id === selected ? ' selected' : '');
      btn.innerHTML = `<span class="category-emoji">${cat.emoji}</span><span>${cat.label}</span>`;
      btn.onclick = () => {
        document.getElementById('event-category').value = cat.id;
        grid.querySelectorAll('.category-option').forEach((el) => el.classList.remove('selected'));
        btn.classList.add('selected');
      };
      grid.appendChild(btn);
    });
  },

  /**
   * Renderiza los chips de filtro por categoría en la vista de lista.
   * @param {Array<Object>} events - para calcular qué categorías tienen eventos
   * @param {string} activeCategory - 'all' o id de categoría
   */
  renderCategoryFilterBar(events, activeCategory) {
    const bar = document.getElementById('category-filter-bar');
    bar.innerHTML = '';

    const allChip = document.createElement('button');
    allChip.type = 'button';
    allChip.className = 'category-chip' + (activeCategory === 'all' ? ' active' : '');
    allChip.textContent = 'Todas';
    allChip.onclick = () => App.setActiveCategory('all');
    bar.appendChild(allChip);

    CATEGORIES.forEach((cat) => {
      const hasEvents = events.some((e) => (e.category || DEFAULT_CATEGORY_ID) === cat.id);
      if (!hasEvents) return;

      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'category-chip' + (activeCategory === cat.id ? ' active' : '');
      chip.textContent = `${cat.emoji} ${cat.label}`;
      chip.onclick = () => App.setActiveCategory(cat.id);
      bar.appendChild(chip);
    });
  },

  /**
   * Muestra un modal por id.
   * @param {string} modalId
   */
  showModal(modalId) {
    document.getElementById(modalId).classList.remove('hidden');
  },

  /**
   * Oculta un modal por id.
   * @param {string} modalId
   */
  hideModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
  },

  /**
   * Lanza confetti animado en la pantalla de celebración.
   */
  launchConfetti() {
    const container = document.getElementById('confetti');
    container.innerHTML = '';
    const colors = COLOR_OPTIONS;

    for (let i = 0; i < 60; i++) {
      const piece = document.createElement('div');
      piece.className = 'confetti-piece';
      piece.style.left = Math.random() * 100 + '%';
      piece.style.background = colors[Math.floor(Math.random() * colors.length)];
      piece.style.animationDuration = 2 + Math.random() * 2 + 's';
      piece.style.animationDelay = Math.random() * 1.5 + 's';
      container.appendChild(piece);
    }
  },
};
